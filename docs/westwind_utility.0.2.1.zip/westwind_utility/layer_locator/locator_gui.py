from qgis.core import *
import os
import ntpath
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from .helperclasses.shpProcessedFileName import shpProcessedFileName
import re
from itertools import chain
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
import datetime
import time
class LocatorGui:

    def __init__(self,_dockWidget):
        print("Starting Locator")
        self.vectorPath = None
        self.project = QgsProject.instance()
        
        self.dockWidget = _dockWidget
        self.treeView = self.dockWidget.locatorTreeView
        self.setProgressBarStart()
        self.populateMissingFiles()

        self.dockWidget.locatorFuzzyMatchSlider.valueChanged.connect(self.handleSliderUpdate)

        self.dockWidget.locatorAllowFuzzyMatchCheckbox.stateChanged.connect(self.handleFuzzyMatchingCheckbox)

        self.dockWidget.locatorRefreshButton.clicked.connect(self.populateMissingFiles)
        self.dockWidget.pushButton_2.clicked.connect(self.testing)
        self.dockWidget.locateSourcesButton.clicked.connect(self.locateMissingFiles)
        self.dockWidget.updateSourcesButton.clicked.connect(self.updateSources)

        self.handleFuzzyMatchingCheckbox()
        
        self.readSettings()

    def testing(self):
        """Populate the source list combobox"""
        print('Populating comboboxs')
        ratio =fuzz.ratio("Catherine M Gitau","Catherine Gitau")
        print(ratio)
        ratio2 = fuzz.ratio("this is a test", "this is a test!")
        print(ratio2)
        print(os.path.dirname(__file__))
        print(os.path.join(os.path.dirname(__file__),'bin\\fuzzywuzzy'))

        #self.locateMissingFiles()

        #self.populateMissingFiles()

    def handleSliderUpdate(self):
        value = self.dockWidget.locatorFuzzyMatchSlider.value()
        self.dockWidget.locatorFuzzyMatchLabel.setText(str(value))

    def handleFuzzyMatchingCheckbox(self,state=Qt.CheckState.Unchecked):
        print(state)
        if not self.dockWidget.locatorAllowFuzzyMatchCheckbox.isChecked():
            print("hiding")
            self.dockWidget.locatorFuzzyMatchLabel.hide()
            self.dockWidget.locatorFuzzyMatchSlider.hide()


        elif self.dockWidget.locatorAllowFuzzyMatchCheckbox.isChecked():
            self.dockWidget.locatorFuzzyMatchLabel.show()
            self.dockWidget.locatorFuzzyMatchSlider.show()



    def updateSources(self):
        print("updating sources")
        self.updateProgressBarLabel("Updating Layer Sources")

        duplicateFiles = False

        for i in range(self.treeViewModel.rowCount()):
            item = self.treeViewModel.item(i)
            if item.hasChildren():
                duplicateFiles=True
                break
        sourceUpdated = False
        if duplicateFiles:
            val = self.showDialog("Have you checked the sources properly?","This cannot be undone")
            print(val)
            if val == 65536:
                self.updateProgressBarLabel("Please revise the sources")
            else:
                
                for i in range(self.treeViewModel.rowCount()):
                    itemUpdated=False
                    index = self.treeViewModel.index(i,3)
                    layerId = self.treeViewModel.data(index)
                    #print(layerId)
                    item = self.treeViewModel.item(i)
                    #print(f"The row count is {item.rowCount()}")
                    if item.rowCount() > 0:
                        
                        for j in range(item.rowCount()):

                            if itemUpdated:
                                break
                            checkState=item.takeChild(j,0).checkState()
                            print(f"the Check state is {checkState}")
                            
                            if checkState == 2:
                                itemUpdated=True
                                sourceUpdated = True
                                newSource = item.takeChild(j,1).text()
                                treeLayers = self.project.layerTreeRoot().findLayers()
                                for treeLayer in treeLayers:
                                    if treeLayer.layerId() == layerId:
                                        source=treeLayer.layer().source()
                                        providerName = treeLayer.layer().dataProvider().name()
                                        
                                        treeLayer.layer().setDataSource(newSource,treeLayer.layer().name(),providerName)

                    else:
                        print("too many sources found")
        self.updateProgressBarLabel("Layer Sources Updated")
        if sourceUpdated:
            self.populateMissingFiles()
 

    def locateMissingFiles(self):
        print('locating Missing files')
        self.updateProgressBarLabel("Locating Missing Files")
        #if self.dockWidget.locatorSearchDirectoriesTextEdit.toPlainText
        searchDirectories = self.dockWidget.locatorSearchDirectoriesTextEdit.toPlainText().split("\n")
        ignoreFolders=self.dockWidget.locatorIgnoreFoldersTextEdit.toPlainText().split("\n")
        self.setProgressBarBusy()
        foundFilesCount=0
        for i in range(self.treeViewModel.rowCount()):
            missingSource = self.treeViewModel.index(i,1).data()
            missingSourceFullFileName=ntpath.basename(missingSource)
            missingSourceExt = os.path.splitext(missingSourceFullFileName)[1]
            #walkData = os.walk(vectorDataPath, topdown=True)
            foundSources =[]
            count = 0
            self.updateProgressBarLabel(f"Searching for file {self.treeViewModel.index(i,0).data()}")
            for roots, dirs, files in chain.from_iterable(os.walk(path) for path in searchDirectories):

                dirs[:] = [d for d in dirs if d not in ignoreFolders]

                index = self.treeViewModel.index(i,2)

                for file in files:
                    count = count+1

                    if not self.dockWidget.locatorAllowDifferentExtensionsCheckbox.isChecked():
                        fileExt=os.path.splitext(file)[1]
                        if not missingSourceExt == fileExt:
                            continue


                    if self.dockWidget.locatorAllowFuzzyMatchCheckbox.isChecked():
                        ratio = fuzz.ratio(missingSourceFullFileName, file)
                        if ratio>self.dockWidget.locatorFuzzyMatchSlider.value():
                            sourceItem = [roots+"\\"+file,ratio]
                            foundSources.append(sourceItem)
                    else:
                        if missingSourceFullFileName == file:
                            sourceItem = [roots+"\\"+file,"NA"]

                            foundSources.append(sourceItem)

                        
            if len(foundSources) >0:
                self.treeViewModel.setData(index,f"Found {len(foundSources)}")
                item = self.treeViewModel.item(i)

                if item.hasChildren():
                    print(f"Root item has {item.rowCount()} rows")
                    item.removeRows(0,item.rowCount())
                    print(f"Now there are {item.rowCount()} rows")

                firstElement=True

                foundSources.sort(key=lambda x: x[1],reverse=True)

                for element in foundSources:
                    

                    newItem=QStandardItem(0,0)
                    newItem_2 = QStandardItem(0,1)
                    newItem.setCheckable(True)
                    newItem.setEditable(False)
                    newItem_2.setEditable(False)
                    if firstElement is True:
                        newItem.setCheckState(2)
                        firstElement = False

                    newItem.setData(ntpath.basename(element[0]),Qt.DisplayRole)
                    newItem_2.setData( element[0],Qt.DisplayRole)
                    newItem_2.setEditable(False)

                    newItem.setToolTip(ntpath.basename(element[0]))
                    newItem_2.setToolTip(element[0])

                    row=[newItem,newItem_2]

                    if self.dockWidget.locatorAllowFuzzyMatchCheckbox.isChecked():
                        newItem_3 = QStandardItem(0,2)
                        newItem_3.setData( element[1],Qt.DisplayRole)
                        newItem_3.setEditable(False)
                        row.append(newItem_3)

                    item.appendRow(row)
                    foundFilesCount=foundFilesCount +1
                    
            else:
                self.treeViewModel.setData(index,"Still Missing")
        self.setProgressBarComplete()
        self.updateProgressBarLabel(f"File searching complete. {foundFilesCount} missing files were located for {self.treeViewModel.rowCount()} layers")


    def updateProgressBarLabel(self,text):
        self.dockWidget.locatorProgessBarLabel.setText(text)
        now=datetime.datetime.now()
        self.dockWidget.locatorLogTextEdit.append("{:<70} {:>0s}".format(text,f"{now}"))
       


    def populateMissingFiles(self):
        missingFileTreeLayers = self.findMissingFiles()
        self.treeViewModel = self.createModel(missingFileTreeLayers)
        self.treeView.setModel(self.treeViewModel)
        self.treeView.setSortingEnabled(True)
        self.updateProgressBarLabel(f"{self.treeViewModel.rowCount()} layers were found with missing files")


    def findMissingFiles(self):
        self.updateProgressBarLabel("Finding layers with missing sources")
        missingFileTreeLayers =[]
        treeLayers = self.project.layerTreeRoot().findLayers()

        for treeLayer in treeLayers:
            source=treeLayer.layer().source()
            cleanSource=source
            reg = re.compile('.*\..*(?=\|)')
            result = reg.match(source)
            if result:
                cleanSource = result[0]


            if not os.path.exists(cleanSource):
                missingFileTreeLayers.append(treeLayer)
                if result:
                    print(source)
                    print(result[0])
                    print(cleanSource)

        return missingFileTreeLayers

    def createModel(self,layerTrees):
        print("creating model")
        #itemModel = myItemModel(0,4,self.treeView)
        itemModel=QStandardItemModel(0, 4, self.treeView)
        #itemModel.setFlags(Qt.NoItemFlags)
        itemModel.setHeaderData(0, Qt.Horizontal, "Layer Name")
        itemModel.setHeaderData(1, Qt.Horizontal, "Layer Source")
        itemModel.setHeaderData(2, Qt.Horizontal, "Status")
        itemModel.setHeaderData(3, Qt.Horizontal, "LayerId")

        for layerTree in layerTrees:
            name = layerTree.name()
            source = layerTree.layer().source()
            reg = re.compile('.*\..*(?=\|)')
            result = reg.match(source)

            if result:
                source = result[0]
            
            layerId = layerTree.layerId()

            itemModel.insertRow(0)
            itemModel.setData(itemModel.index(0, 0), name)
            itemModel.item(0,0).setFlags(Qt.ItemIsEnabled )
            itemModel.item(0,0).setToolTip(name)

            itemModel.setData(itemModel.index(0, 1), source)
            itemModel.item(0,1).setFlags(Qt.ItemIsEnabled and Qt.ItemIsSelectable)
            itemModel.item(0,1).setToolTip(source)

            itemModel.setData(itemModel.index(0, 2), "Not Found")
            itemModel.item(0,2).setFlags(Qt.ItemIsEnabled and Qt.ItemIsSelectable)

            itemModel.setData(itemModel.index(0, 3), layerId)
            itemModel.item(0,3).setFlags(Qt.ItemIsEnabled and Qt.ItemIsSelectable)
        
        return itemModel
            #data=[name,source,"Not Found",layerId]
            #dataList.append(data)

    # def tabulateMissingFiles(self,layerTrees):
    #     dataList=[]
    #     for layerTree in layerTrees:
    #         name = layerTree.name()
    #         source = layerTree.layer().source()
    #         reg = re.compile('.*\..*(?=\|)')
    #         result = reg.match(source)
    #         if result:
    #             source = result[0]


    #         layerId = layerTree.layerId()
    #         data=[name,source,"Not Found",layerId]
    #         dataList.append(data)
    #     return dataList

    # def setupTableView(self,dataList):
    #     header = ['Layer Name', 'Layer Source', 'Status','LayerId']
    #     self.tableModel=LocatorTableModel(self.treeView,dataList,header)
    #     self.treeView.setModel(self.tableModel)
    #     self.treeView.setSortingEnabled(True)

    def showDialog(self,text_1,text_2):
        print("showing dialog")
        #msg = QMessageBox.question(self.dockWidget, text_1,text_2,QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Critical)

        msg.setText(text_1)
        msg.setInformativeText(text_2)
        msg.setWindowTitle("Warning")
        #msg.setDetailedText("The details are as follows:")
        #msg.addButton(QPushButton)
        msg.setStandardButtons(QMessageBox.Yes )
        msg.addButton(QMessageBox.No)
        #msg.buttonClicked.connect(msgbtn)
        retval = msg.exec_()
        print ("value of pressed message box button:", retval )
        return retval
        #if (retval==8192):
            



    def setProgressBarBusy(self):
        self.dockWidget.locatorProgressBar.setMinimum(0)
        self.dockWidget.locatorProgressBar.setMaximum(0)
        self.dockWidget.locatorProgressBar.setValue(0)

    def setProgressBarComplete(self):
        self.dockWidget.locatorProgressBar.setMinimum(0)
        self.dockWidget.locatorProgressBar.setMaximum(1)
        self.dockWidget.locatorProgressBar.setValue(1)

    def setProgressBarStart(self):
        self.dockWidget.locatorProgressBar.setMinimum(0)
        self.dockWidget.locatorProgressBar.setMaximum(1)
        self.dockWidget.locatorProgressBar.setValue(0)

    def storeSettings(self):
        s=QgsSettings()
        print("Storing Locator Settings")
        s.setValue("layerlocator/ignorefolders",self.dockWidget.locatorIgnoreFoldersTextEdit.toPlainText())
        s.setValue("layerlocator/searchdirectories",self.dockWidget.locatorSearchDirectoriesTextEdit.toPlainText())
        s.setValue("layerlocator/allowfuzzymatching",self.dockWidget.locatorAllowFuzzyMatchCheckbox.checkState())
        s.setValue("layerlocator/fuzzymatchingvalue",self.dockWidget.locatorFuzzyMatchSlider.value())
        s.setValue("layerlocator/asktoresolverduplicates",self.dockWidget.locatorResolveDuplicateFilesCheckbox.checkState())
    
    def readSettings(self):
        s=QgsSettings()
        print("Reading Locator Settings")
        self.dockWidget.locatorIgnoreFoldersTextEdit.setText(s.value("layerlocator/ignorefolders","workingFiles\nmapworkingData"))
        self.dockWidget.locatorSearchDirectoriesTextEdit.setText(s.value("layerlocator/searchdirectories","workingFiles\nmapworkingData"))
        self.dockWidget.locatorAllowFuzzyMatchCheckbox.setCheckState(int(s.value("layerlocator/allowfuzzymatching","0")))
        self.dockWidget.locatorFuzzyMatchSlider.setValue(int(s.value("layerlocator/fuzzymatchingvalue","100")))
        self.dockWidget.locatorResolveDuplicateFilesCheckbox.setCheckState(int(s.value("layerlocator/asktoresolverduplicates","0")))



class myItemModel (QStandardItemModel):
    def __init__(self, row, col, parent, *args):
        QAbstractItemModel.__init__(self,parent, *args)


    def data(self, index, role):
        row = index.row()
        col = index.column()
        #role = Qt.EditRole
        #print(role)
        if not index.isValid():
            return None

        elif role != Qt.DisplayRole:
            return None
            

        return self.mylist[row][col]


    def setData(self,index, value, role=Qt.EditRole):
        print("setting Data")
        if (not index.isValid() and role != Qt.EditRole):
            return false

        #self.mylist[index.row()][index.column()] = str(value)
        self.dataChanged.emit(index, index)
        return True



# class LocatorTableModel(QAbstractTableModel):
#     def __init__(self, parent, mylist, header, *args):
#         QAbstractTableModel.__init__(self, parent, *args)
#         self.mylist = mylist
#         self.header = header
#         #self.dataStore =[][]
        

#     def rowCount(self, parent):
#         return len(self.mylist)

#     def columnCount(self, parent):
#         return len(self.mylist[0])

#     def data(self, index, role):
#         row = index.row()
#         col = index.column()
#         #role = Qt.EditRole
#         #print(role)
#         if not index.isValid():
#             return None

        

#         elif role != Qt.DisplayRole:
#             return None
            

#         return self.mylist[row][col]

#     def setData(self,index, value, role=Qt.EditRole):
#         print("setting Data")
#         if (not index.isValid() and role != Qt.EditRole):
#             return false

#         self.mylist[index.row()][index.column()] = str(value)
#         self.dataChanged.emit(index, index)
#         return True

#     def headerData(self, col, orientation, role):
#         if orientation == Qt.Horizontal and role == Qt.DisplayRole:
#             return self.header[col]
#         return None

#     def sort(self, col, order):
#         """sort table by given column number col"""
#         self.layoutAboutToBeChanged.emit()
#         self.mylist.sort(key=lambda x: x[col])
#         if order == Qt.DescendingOrder:
#             self.mylist.reverse()
#         self.layoutChanged.emit()


