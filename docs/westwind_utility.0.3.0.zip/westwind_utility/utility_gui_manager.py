import os
from .utility_core_dockwidget import UtilityDockWidget
from .layer_sourcechanger.sourcechanger_gui import SourceChangerGui
from .layer_importer.importer_gui import ImporterGui
from .layer_locator.locator_gui import LocatorGui
#from .mytreeview import mytreeview

class UtilityGuiManager:
    
    def __init__(self):
        self.dockWidget = UtilityDockWidget()
        self.importer = ImporterGui(self.dockWidget)
        self.sourcechanger_gui= SourceChangerGui(self.dockWidget,self.importer)
        self.locator = LocatorGui(self.dockWidget)


