from qgis.core import *
import os
import ntpath
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from .helperclasses.shpProcessedFileName import shpProcessedFileName

class LocatorGui:

    def __init__(self,_dockWidget):
        print("Starting Locator")
        self.vectorPath = None
        self.project = QgsProject.instance()
        
        self.dockWidget = _dockWidget
        self.treeView = self.dockWidget.locatorTreeView
        self.populateMissingFiles()

        self.dockWidget.locatorRefreshButton.clicked.connect(self.populateMissingFiles)
        self.dockWidget.pushButton_2.clicked.connect(self.testing)
        self.dockWidget.locateSourcesButton.clicked.connect(self.locateMissingFiles)
        self.dockWidget.updateSourcesButton.clicked.connect(self.updateSources)
        
        
        


    def testing(self):
        """Populate the source list combobox"""
        print('Populating comboboxs')
        self.locateMissingFiles()
        #self.populateMissingFiles()

    def updateSources(self):
        print("updating sources")
        for i in range(self.treeViewModel.rowCount()):
            index = self.treeViewModel.index(i,3)
            layerId = self.treeViewModel.data(index)
            print(layerId)
            item = self.treeViewModel.item(i)
            print(f"The row count is {item.rowCount()}")
            if item.rowCount() is 1:
                
                newSource = item.takeChild(0,0).text()
                print(f"the New source is {newSource}")
                treeLayers = self.project.layerTreeRoot().findLayers()
                for treeLayer in treeLayers:
                    if treeLayer.layerId() == layerId:
                        source=treeLayer.layer().source()
                        providerName = treeLayer.layer().dataProvider().name()
                        
                        treeLayer.layer().setDataSource(newSource,treeLayer.layer().name(),providerName)
            else:
                print("too many sources found")
        self.populateMissingFiles()
 

    def locateMissingFiles(self):
        print('locating Missing files')
        vectorDataPath = QgsExpressionContextUtils.projectScope(self.project).variable('project_importpath')
        #vectorDataPath="C:\\Users\\timc7\\Dropbox (Personal)\\Tim\\Employment\\WestWind Energy\\Work\\GIS\\QGIS\\VectorData"
        print(vectorDataPath)
        

        for i in range(self.treeViewModel.rowCount()):
            #print(f"The value of i is {i}")
            #print(f"row count is {self.treeViewModel.rowCount()}")
            missingSource = self.treeViewModel.index(i,1).data()
            missingSourceFullFileName=ntpath.basename(missingSource)
            walkData = os.walk(vectorDataPath, topdown=True)
            foundSources =[]
            count = 0
            for roots, dirs, files in walkData:
                index = self.treeViewModel.index(i,2)

                for file in files:
                    count = count+1
                    if len(foundSources) <1 and (count % 1) == 0:
                        self.treeViewModel.setData(index,count)

                    if missingSourceFullFileName == file:
                        foundSources.append(roots+"\\"+file)
                        #print(len(foundSources))
                        
            if len(foundSources) is 1:
                self.treeViewModel.setData(index,"Found")
                item = self.treeViewModel.item(i)
                if item.hasChildren():
                    print(f"Root item has {item.rowCount()} rows")
                    item.removeRows(0,item.rowCount())
                    print(f"Now there are {item.rowCount()} rows")

                for source in foundSources:
                    print(f"found source {source}")
                    newItem=QStandardItem(0,0)
                    
                    newItem.setData( source,Qt.DisplayRole)
                    #newItem.setFlags(33)
                    newItem.setFlags(Qt.ItemIsEnabled)
                    item.appendRow(newItem)

            elif len(foundSources) >1:
                self.treeViewModel.setData(index,f"Found {len(foundSources)}")
                item = self.treeViewModel.item(i)
                if item.hasChildren():
                    print(f"Root item has {item.rowCount()} rows")
                    item.removeRows(0,item.rowCount())
                    print(f"Now there are {item.rowCount()} rows")


                #print(f"the data is {item.data()}")
                for source in foundSources:
                    newItem=QStandardItem(0,0)
                    
                    newItem.setData( source,Qt.DisplayRole)
                    #newItem.setFlags(33)
                    newItem.setFlags(Qt.ItemIsEnabled)
                    item.appendRow(newItem)
                    
            else:
                self.treeViewModel.setData(index,"Still Missing")

    def populateMissingFiles(self):
        missingFileTreeLayers = self.findMissingFiles()
        self.treeViewModel = self.createModel(missingFileTreeLayers)
        self.treeView.setModel(self.treeViewModel)
        self.treeView.setSortingEnabled(True)
        #dataList = self.tabulateMissingFiles(missingFileTreeLayers)
        #self.setupTableView(dataList)

    def findMissingFiles(self):

        missingFileTreeLayers =[]
        treeLayers = self.project.layerTreeRoot().findLayers()

        for treeLayer in treeLayers:
            source=treeLayer.layer().source()
            if not os.path.exists(source):
                missingFileTreeLayers.append(treeLayer)

        return missingFileTreeLayers

    def createModel(self,layerTrees):
        print("creating model")
        #itemModel = myItemModel(0,4,self.treeView)
        itemModel=QStandardItemModel(0, 4, self.treeView)
        #itemModel.setFlags(Qt.NoItemFlags)
        itemModel.setHeaderData(0, Qt.Horizontal, "Layer Name")
        itemModel.setHeaderData(1, Qt.Horizontal, "Layer Source")
        itemModel.setHeaderData(2, Qt.Horizontal, "Status")
        itemModel.setHeaderData(3, Qt.Horizontal, "LayerId")

        for layerTree in layerTrees:
            name = layerTree.name()
            source = layerTree.layer().source()
            layerId = layerTree.layerId()
            itemModel.insertRow(0)
            itemModel.setData(itemModel.index(0, 0), name)
            itemModel.setData(itemModel.index(0, 1), source)
            itemModel.setData(itemModel.index(0, 2), "Not Found")
            itemModel.setData(itemModel.index(0, 3), layerId)
        
        return itemModel
            #data=[name,source,"Not Found",layerId]
            #dataList.append(data)
        

    def tabulateMissingFiles(self,layerTrees):
        dataList=[]
        for layerTree in layerTrees:
            name = layerTree.name()
            source = layerTree.layer().source()
            layerId = layerTree.layerId()
            data=[name,source,"Not Found",layerId]
            dataList.append(data)
        return dataList

    def setupTableView(self,dataList):
        header = ['Layer Name', 'Layer Source', 'Status','LayerId']
        self.tableModel=LocatorTableModel(self.treeView,dataList,header)
        self.treeView.setModel(self.tableModel)
        self.treeView.setSortingEnabled(True)


class myItemModel (QStandardItemModel):
    def __init__(self, row, col, parent, *args):
        QAbstractItemModel.__init__(self,parent, *args)


    def data(self, index, role):
        row = index.row()
        col = index.column()
        #role = Qt.EditRole
        #print(role)
        if not index.isValid():
            return None

        elif role != Qt.DisplayRole:
            return None
            

        return self.mylist[row][col]


    def setData(self,index, value, role=Qt.EditRole):
        print("setting Data")
        if (not index.isValid() and role != Qt.EditRole):
            return false

        #self.mylist[index.row()][index.column()] = str(value)
        self.dataChanged.emit(index, index)
        return True



class LocatorTableModel(QAbstractTableModel):
    def __init__(self, parent, mylist, header, *args):
        QAbstractTableModel.__init__(self, parent, *args)
        self.mylist = mylist
        self.header = header
        #self.dataStore =[][]
        

    def rowCount(self, parent):
        return len(self.mylist)

    def columnCount(self, parent):
        return len(self.mylist[0])

    def data(self, index, role):
        row = index.row()
        col = index.column()
        #role = Qt.EditRole
        #print(role)
        if not index.isValid():
            return None

        # elif row is 0 :
        #     bold = QFont()
        #     bold.setBold(True)
        #     return self.mylist[row][col]
        

        elif role != Qt.DisplayRole:
            return None
            

        return self.mylist[row][col]

    def setData(self,index, value, role=Qt.EditRole):
        print("setting Data")
        if (not index.isValid() and role != Qt.EditRole):
            return false

        self.mylist[index.row()][index.column()] = str(value)
        self.dataChanged.emit(index, index)
        return True

    def headerData(self, col, orientation, role):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self.header[col]
        return None

    def sort(self, col, order):
        """sort table by given column number col"""
        #self.emit(SIGNAL("layoutAboutToBeChanged()"))
        self.layoutAboutToBeChanged.emit()
        self.mylist.sort(key=lambda x: x[col])
        #self.mylist = sorted(self.mylist,
        #    key=operator.itemgetter(col))
        if order == Qt.DescendingOrder:
            self.mylist.reverse()
        self.layoutChanged.emit()
        #self.emit(SIGNAL("layoutChanged()"))
