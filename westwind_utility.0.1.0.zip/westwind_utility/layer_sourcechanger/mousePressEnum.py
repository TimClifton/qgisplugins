from enum import Enum

class mousePressEnum(Enum):
    leftclick = 1
    rightclick =2
    middleclick = 3