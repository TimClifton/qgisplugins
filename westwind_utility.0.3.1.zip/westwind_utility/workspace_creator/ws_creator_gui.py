from qgis.core import *
import os
import ntpath
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import re
from itertools import chain
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
import datetime
import time
import random
import multiprocessing
import pathlib

MESSAGE_CATEGORY = 'Layer Locator'
MESSAGE_CATEGORY_DEBUG = 'Layer Locator Debug'

class WSCreatorGui:

    def __init__(self,_dockWidget):
        print("Starting WSCreator")
        self.vectorPath = None
        self.project = QgsProject.instance()
        
        self.dockWidget = _dockWidget
        self.dockWidget.WSCreator_RunButton.clicked.connect(self.run)
        #self.directory = 'E:\WWE\Proj - Files\P000_CHEP\GIS_Maps\VectorData\globaldata'
        self.directory = None
        self.treeRoot = QgsProject.instance().layerTreeRoot()
        self.dockWidget.WSC_selectDirPushButton.clicked.connect(self.selectDir)


    def run(self):
        if not self.directory:

            if os.path.isdir(self.dockWidget.WSC_DirectoryLineEdit.text()):
                self.directory = self.dockWidget.WSC_DirectoryLineEdit.text()

            else:

                self.showDialog()
                return

        self.directory = os.path.abspath(self.directory)
        self.dockWidget.WSC_DirectoryLineEdit.setText(self.directory)


        baseGroupName = os.path.basename( self.directory)

        globalDataGroup = self.treeRoot.findGroup(baseGroupName)

        if not globalDataGroup:
            self.treeRoot.addGroup(baseGroupName)

        globalDataGroup = self.treeRoot.findGroup(baseGroupName)


        for path, dirs, files in os.walk(self.directory):
            for f in files:
                foundFile, foundFileExt = os.path.splitext(f)
                foundFilePath = os.path.join(path, f)
                
                if foundFileExt == '.shp':
                    relativePath = path.replace(self.directory,'')
                    parentFolders = relativePath.split('\\')

                    if '' in parentFolders:
                        parentFolders.remove('')

                    #print(parentFolders)
                    parentGroup = globalDataGroup

                    for folder in parentFolders:
                        #Find if the group exists
                        result = parentGroup.findGroup(folder)

                        if not result:
                            parentGroup = parentGroup.addGroup(folder)
                        
                        else:
                            parentGroup = result

                    #Find all the layers that exist in the parent group
                    existingLayers = parentGroup.findLayers()
                    layerExists = False

                    for l in existingLayers:
                        existingLayerSource = l.layer().source()
                        if existingLayerSource == foundFilePath:
                            layerExists = True

                    if not layerExists:
                        vectorLayer = QgsVectorLayer(foundFilePath, foundFile)
                        mapLayer = QgsProject.instance().addMapLayer(vectorLayer,False)

                        parentGroup.addLayer(vectorLayer)


        QgsMessageLog.logMessage(f'here', MESSAGE_CATEGORY_DEBUG, Qgis.Info)
        QgsMessageLog.logMessage(f'{path}', MESSAGE_CATEGORY_DEBUG, Qgis.Info)


    def showDialog(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Critical)

        msg.setText("Vector data path has not been set")
        msg.setInformativeText("Please set the vector data path before running the import. This only has to be set once")
        msg.setWindowTitle("Path not Set")

        msg.setStandardButtons(QMessageBox.Open)
 
        retval = msg.exec_()
        print ("value of pressed message box button:", retval )
        
        if (retval==8192):
            self.selectDir()


    def selectDir( self ):
        """ Open a dialog for the user to choose a starting directory """

        self.directory = QFileDialog.getExistingDirectory(self.dockWidget, 'Select vector data path', '/home', QFileDialog.ShowDirsOnly)
        self.directory = os.path.abspath(self.directory)
        self.dockWidget.WSC_DirectoryLineEdit.setText(self.directory)